<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 19/03/18
 * Time: 16:00
 */
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Inicial</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="node_modules/semantic-ui/dist/semantic.min.css">
	<script
  		src="https://code.jquery.com/jquery-3.1.1.min.js"
  		integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  		crossorigin="anonymous"></script>
	<script src="node_modules/semantic-ui/semantic.min.js"></script>
    <style type="text/css">
    	@media only screen and (max-width: 700px) {
    		.ui.fixed.menu {
    			display: none !important;
    		}
    	}
    </style>
</head>
<body>
<div class="ui massive attached stackable container inverted menu">
    <div class="item">
        <img src="node_modules/semantic-ui/logo.png">
    </div>            
                <a class="item" href="index.php">Início</a>
            <?php
            if (!isset($_SESSION['logado'])){?>
                <a class="item" href="?acao=cadastrar">Cadastrar</a>
                <a class="item" href="?acao=login">Logar</a>
            <?php }
            if (isset($_SESSION['logado'])){?>
                <a class="item" href="#">Favoritos</a>
                <a class="item" href="#">Perfil</a>
                <a class="item" href="app/controllers/controladorAcao.php?acao=sair">Sair</a>
            <?php
            if (isset($_SESSION['logado']) and isset($_SESSION['tipo'])){?>
                <a class="item" href="app/controllers/carro.php?acao=admin">ADMIN</a>
            <?php } ?>
            <?php } ?>
               <a class="item" href="#">Sobre e Contatos</a>
    </div>
<br>
<br>
<br>    
<?php
if (!isset($_SESSION['logado']) and isset($_GET['acao']) and $_GET['acao'] == 'login') {
    require_once "include/login.php";
}elseif (!isset($_SESSION['logado']) and isset($_GET['acao']) and $_GET['acao'] == 'cadastrar'){
    require_once "include/cadastro.php";
}elseif (!isset($_GET['acao'])){?>
    <select>
        <option value="-1">Selecione</option>
    </select>
    <select>
        <option value="-1">Selecione</option>
    </select>
    <select>
        <option value="-1">Selecione</option>
    </select>
<?php }
?>
</div>
</body>
</html>