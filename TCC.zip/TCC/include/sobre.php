<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 26/04/18
 * Time: 16:18
 */
?>
<div class="ui text container">
<p style="display: block;
    -webkit-margin-before: 1em;
    -webkit-margin-after: 1em;
    -webkit-margin-start: 0px;
    -webkit-margin-end: 0px;
    font-size: 20px;">
    Essa é uma aplicação desenvolvida por alunos do Instituto Federal Catarinense Câmpus Araquari com o intuito de ajudar consumidores automotivos na sua decisão
</p>
</div>
<div class="ui center aligned grid">
    <div style="background-color: red;" class="five wide column">
       <img src="assets/images/lula.jpg">
    </div>
    <div style="background-color: blue;" class="five wide column">
       <img src="assets/images/dilma.jpg">
    </div>
    <div style="background-color: yellow;" class="five wide column">
       <img src="assets/images/temer.jpg">
    </div>
</div>
