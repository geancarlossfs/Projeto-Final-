<?php
/**
 * Created by PhpStorm.
 * User: Henrique Hartmann
 * Date: 02/04/2018
 * Time: 20:08
 */
require_once '../models/CrudUsuario.php';

if (isset($_GET['acao']) and $_GET['acao'] == 'cadastrar')
{
    $user = new Usuario($_POST['nome'], $_POST['email'], $_POST['senha'], 'comum');

    $usercrud = new CrudUsuario();

    $usercrud->insertUsuario($user);

}
elseif (isset($_GET['acao']) and $_GET['acao'] == 'login' and isset($_POST['nome']) and isset($_POST['senha']))
{
    $user = new Usuario($_POST['nome'], '@gmail.com', $_POST['senha']);

    $usercrud = new CrudUsuario();

    $usercrud->loginUser($user);

    echo "Loading Page";
}
elseif (isset($_GET['acao']) and $_GET['acao'] == 'sair')
{
    session_start();

    session_destroy();

    header('location:../../index.php');
}