<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 10/04/18
 * Time: 13:39
 */
?>
<table class="table table-bordered table-responsive-xl">
    <thead>

    <tr>
    <th>Id Veículo</th>
    <th>Montadora</th>
    <th>Modelo</th>
    <th>Ano</th>
    <th>Versão</th>
    <th>Carro</th>
    <th>Potencia</th>
    <th>Portas</th>
    <th>Preco</th>
    <th>Altura</th>
    <th>Comprimento</th>
    <th>Largura</th>
    <th>Câmbio</th>
    <th>Velocidade</th>
    <th>Tanque de Combustível</th>
    <th>Tipo de Combustível</th>
    <th>Porta Malas</th>
    <th>Tipo de Direção</th>
    <th>Consumo Urb.</th>
    <th>Consumo Rod.</th>
    <th>Marcha</th>
    <th>Tipo de Tração</th>
    <th>Porte</th>
    <th>Ocupantes</th>
    <th>Tipo do Freio</th>
    <th>Tipo do Veículo</th>
    </tr>

    </thead>
    <tbody>
    <?php foreach ($categorias as $categoria): ?>
        <tr>
            <th scope="row"><?= $categoria->getId() ?></th>
            <td><?=$categoria->getNome() ?></td>
            <td><?=$categoria->getDescricao() ?></td>
            <td><a href="editar-produto.php?action=editar&codigo=<?=$categoria->getId();?>&nome=<?=$categoria->getNome();?>&descricao=<?=$categoria->getDescricao();?>">Editar</a> | <a href="controleAcao.php?action=excluir&codigo=<?=$categoria->getId();?>">Excluir</a></td>
        </tr>
    <?php endforeach ?>

    </tbody>
</table>
</body>