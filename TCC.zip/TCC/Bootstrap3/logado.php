<!DOCTYPE html>
<html>
<head>
	<title></title>

	<!-- define a viewport -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="utf-8">

	<!-- adicionar CSS Bootstrap -->
	<!-- CSS offline
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" media="screen"> -->
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" media="screen">
	
	<!-- CSS personalizado -->
	<link rel="stylesheet" type="text/css" href="css/estilo.css" media="screen">

	<!-- Fonte personalizada -->
	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Monoton"/>
	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Orbitron"/>

</head>
<body>

	<div class="clearfix container menu">
		<div class="row menu-top">
			<div class="col-xs-12 col-md-9 col-lg-9 menu-text">
				<h2>Apoio a Decisão ao Consumidor Automotivo</h2>
			</div>
			<div class="col-xs-12 col-md-3 col-lg-3 menu-a">
				<a class="botao cadastro" href="">Logout</a>
				<a class="botao login" href="">Favoritos</a>	
			</div>
		</div>
		<br />
	</div>
	
	<div class="clearfix container search">
	<br />
		<div class="row search-top">
			<div class="col-md-3 col-md-3 white-space"></div>
        	<div class="col-xs-12 col-md-6 col-lg-6">
            	<div id="search-input">
                	<div class="input-group col-md-12">
                    	<input type="text" class="form-control input-lg" placeholder="Buscar" />
                    	<span class="input-group-btn">
                        <button class="btn btn-success btn-lg" type="button">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    	</span>
                	</div>
            	</div>
        	</div>
		</div>
		<br />
	</div>
	
	<div class="container box-comparacao">
		<h1>COMPARAÇÃO</h1>
		<br />
		<div class="row comparacao-top">
			<div class="col-md-4 box-add">
								<a class="add-comparacao" href="">+</a>
			</div>
			<div class="col-md-4 box-add">
								<a class="add-comparacao" href="">+</a>
			</div>
			<div class="col-md-4 box-add">
								<a class="add-comparacao" href="">+</a>
			</div>
		</div>
		<br />
	</div>
	
	<footer class="clearfix footer">
		<div class="container footer-container">
			<p class="text-muted">Copyright &copy; 2017 IFC | Design by Curso Técnico Info <a href="http://araquari.ifc.edu.br/">IFC-ARAQUARI</a></p>
		</div>
	</footer>



<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
<!-- JS offline
<script type="text/javascript" src="js/bootstrap.min.js"></script> -->
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>