<!--https://www.youtube.com/watch?v=xVYrz61IBpQ-->
<!--https://www.youtube.com/watch?v=_e-wxg3T1nE-->
<!--https://www.youtube.com/watch?v=yiif8r_U120-->
<!--https://www.youtube.com/watch?v=HL4R6se1y8g-->
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Página Incial</title>
	<link rel="stylesheet" type="text/css" href="CSS/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="CSS/Outros.css">
	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Rock+Salt" />
</head>
<body>
	<div id="topo"></div>
	<div id="menu"><!--menu-->
		<ul>
			<li><a href="">Início</a></li>
			<li><a href="">Favoritos</a></li>
			<li><a href="">Sobre</a></li>
			<li><a href="login.php">Entrar</a></li>
		</ul>
	</div>
<br>
	<div id="content">
		<h2>Bem Vindo Ao Nosso Site.</h2>
	</div>
	<div id="content2">
		<p>Favorite e Comente em nosso conteúdo. Para acessar esses conteúdos exclusivos basta criar uma conta ou faça login.</p>
	</div>
<br>
<br>
<br>
<br>
	<div id="cadastro">
		<a href="cadastro.php" class="btn btn-block btn-lg btn-success">Criar Conta</a>	
	</div>
	<div id="pula_linha">
		
	</div>
	<div id="titulo"><h1>Sistema para apoio a decisão do consumidor automotivo.</h1></div>
	
</body>
</html>